

#Question 2
VALID_PASSWORD="doggie123"
echo "Enter the password:"
read user_password

if [[ "$user_password" = "$VALID_PASSWORD" ]]; then 
	echo "Access Granted!"
else
	echo "Access Denied!"
fi
