
#Question 1
echo "Hello! This is the first shell scripting exercise  for module CO1101"
echo "The script is being run by $USER"
echo "The current directory is $PWD"
