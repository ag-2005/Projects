//Interface for checking eligibility and printing customer details
interface CheckerPrinter {
  boolean checkEligibility(Customer customer); // Method to check eligibility for a specific customer
  boolean checkEligibility(); // Method to check eligibility (possibly for the current instance)
  void printCustomerDetails(); // Method to print customer details
  void printCustomerDetails(Customer customer); // Method to print details for a specific customer
}