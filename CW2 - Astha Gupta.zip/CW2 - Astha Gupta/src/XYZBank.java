import java.util.Scanner; // Import scanner
import java.util.ArrayList; // Import arrays
import java.util.InputMismatchException; // Import mismatch exception handling 
import java.util.List; // Import list
import java.util.Random; // Import random

public class XYZBank {
  private static List < Customer > customers = new ArrayList < > (); // Stores Customer ID in the list
  private static Scanner input = new Scanner(System.in); // Create variable for scanner 
  private static Random random = new Random(); // Create variable for random
  private static List < Integer > generatedNumbers = new ArrayList < > (); // Stores a list for randomised record ID
  private static int registeredRecords = 0; //Initialise registered record to 0
  private static int maxRecords = 0; // Initialise max record to 0

  public static void main(String[] args) {
    addMaxRecords(); // Use private static void to set max record
    boolean exit = false; // Initialise variable exit = false
    while (!exit) { // Created a loop until user choose case 8 
      displayMenu(); // Displays all the options user can do
      try { // Try and catch exception handling 
        int choice = input.nextInt(); // System reads the digit user entered
        input.nextLine(); // Consume newline character

        switch (choice) { // Use switch to do command on the case **
        case 1:
          registerNewCustomers(); // Register customer if user chooses 1
          break;
        case 2:
          addLoanRecord(); // Add loan record if user chooses 2
          break;
        case 3:
          removeLoanRecord(); // Remove loan record if user chooses 3
          break;
        case 4:
          updateCustomerIncome(); // Update customer Income if user chooses 4
          break;
        case 5:
          updateLoanRecord(); // Update loan record if user chooses 5
          break;
        case 6:
          printCustomerDetails(); // Print a specific customer detail if user chooses 6
          break;
        case 7:
          printAllCustomerDetails(); // Print all customer details if user chooses 7
          break;
        case 8:
          exit = true; // This breaks the loop. Exit = True
          System.out.println("Thank you for using XYZ Bank!"); // Message to let the user know that it's been completed
          break;
        default:
          // User doesn't enter a number between 1-8 within the loop.
          System.out.println("Invalid choice. Please enter a number between 1 and 8.");
          break;
        }
      } catch (InputMismatchException e) { // If user enters a letter - instead of a number
        System.out.println("Invalid input. Please enter a number between 1 and 8.");
        input.nextLine(); // Consume invalid input
      }
    }
  }

  // SET MAX RECORD 

  private static void addMaxRecords() {
    while (true) { // Loop
      try { // Try and catch exception handling
        System.out.print("Enter the maximum number of records: "); // User inputs the maximum records
        maxRecords = input.nextInt(); // Stored into maxRecords 
        break; // Breaks loop
      } catch (InputMismatchException e) {
        System.out.println("Invalid input. Please enter a valid positive integer."); // User doesn't put a valid integer
        input.nextLine(); // Make user to re-type 
      }
    }
  }

  private static void displayMenu() { // Displays the menu for the user to see and enter choice 
    System.out.println();
    System.out.println("XYZBank Loan Management System");
    System.out.println("Please enter one the following options below:");
    System.out.println();
    System.out.println("1. Register new customer");
    System.out.println("2. Add a new loan record ");
    System.out.println("3. Remove a loan record");
    System.out.println("4. Update income for customer");
    System.out.println("5. Update loan record for customer");
    System.out.println("6. Print specific customer details");
    System.out.println("7. Print details for all existing customers");
    System.out.println("8. Exit");
    System.out.println();
    System.out.print("Enter your choice: "); // User enters a number here 
  }

  // REGISTER NEW CUSTOMER 

  private static void registerNewCustomers() { // Register new customers
    System.out.print("Enter customer ID (e.g. ABC123): "); // Send a message to the user to input their customer ID
    String customerID = input.nextLine().toUpperCase(); // User puts in the customer ID given that they have one
    if (!isValidCustomerID(customerID)) {
      System.out.println("Invalid customer ID format. Customer ID must be 3 letters followed by 3 digits.");
      return; // Returns to the display menu after user inputs the invalid customerID
    }

    // Check if customer ID already exists
    if (findCustomerID(customerID) != null) { // If the customer exists, it would send out a message that customerID already existed
      System.out.println("Customer with the provided ID already exists.");
      return; // Return to the display menu
    }

    double income = 0; // Initialise income to 0
    boolean validIncome = false; // Set Valid Income to False
    while (!validIncome) {
      System.out.print("Enter your Annual income (in thousands e.g. 1 = £1000): "); // Enter a valid income amount
      if (input.hasNextDouble()) {
        income = input.nextDouble() * 1000; // Multiply a thousand 
        if (income > 0) {
          validIncome = true; // Breaks the loop if user types the correct value
        } else {
          System.out.println("Invalid input. Please enter a positive number."); // Notifies user they didn't type a positive number 
        }
      } else {
        System.out.println("Invalid input. Please enter a valid number."); // Notifies user that they typed in a symbols other than numbers
        input.next();
      }
    }

    Customer customer = new Customer(customerID, income); // Read the customer ID and income into customer class
    customer.setEligibilityStatus(customer.checkEligibility()); // Check eligibility on the income 
    customers.add(customer); // Stores the customer ID
    System.out.println("Customer registered successfully.");
  }

  // ADD LOAN RECORD

  private static void addLoanRecord() {
    if (registeredRecords >= maxRecords) { // Check if the number of registered records is equal to or greater than the maximum allowed records
      System.out.println("Maximum number of records reached.");
      return; // Return to the display menu as it's not possible to add any more records
    }

    System.out.print("Enter customer ID: "); // Get customer ID from the user
    String customerID = input.nextLine().toUpperCase(); // Set all letters to capitalise and read user's input 

    Customer customer = findCustomerID(customerID); // Find the corresponding Customer object in the customers list
    if (customer == null) {
      System.out.println("Customer not found.");
      return; // Customer ID is not found hence the user returns to the display menu
    }

    if (!customer.getEligibilityStatus()) { // Verify eligibility before adding a new loan
      System.out.println("Customer is not eligible to add a new loan.");
      return; // If loan amount > income * 4 they won't be able to add a new record 
    }

    // Validate interest rate
    double interestRate;
    while (true) {
      System.out.print("Enter interest rate: ");
      if (input.hasNextDouble()) { // User enters the interest rate after the given message
        interestRate = input.nextDouble();
        if (interestRate > 0) {
          break; // Valid interest rate, exit loop
        } else {
          System.out.println("Interest rate must be greater than 0."); // User enters a negative interest
        }
      } else {
        System.out.println("Invalid input. Please enter a valid interest rate."); // User didn't put a number 
        input.next(); // Consume invalid input
      }
    }

    int TimeLeft;
    while (true) {
      System.out.print("Enter loan time left (in years): ");
      if (input.hasNextInt()) { // User enters the time left after the given message
        TimeLeft = input.nextInt();
        if (TimeLeft > 0) {
          break; // Valid loan term left, exit loop
        } else {
          System.out.println("Loan term left must be greater than 0."); //User typed in a negative value
        }
      } else {
        System.out.println("Invalid input. Please enter a valid integer."); // User didn't type a number 
        input.next(); // Consume invalid input
      }
    }

    // Validate amount left
    double amountLeft;
    while (true) {
      System.out.print("Enter amount left (in thousands): ");
      if (input.hasNextDouble()) { // User enters the amount left
        amountLeft = input.nextDouble() * 1000;
        if (amountLeft > 0) {
          break; // Valid amount left, exit loop
        } else {
          System.out.println("Amount left must be greater than 0."); // User typed in a negative value
        }
      } else {
        System.out.println("Invalid input. Please enter a valid amount left."); // User didn't type a number 
        input.next(); // Consume invalid input
      }
    }
    input.nextLine(); // Consume the newline character

    String recordID = generateRecordID();
    Loan loan = null; // Create a new Loan object based on the provided details
    System.out.print("Enter loan type (Auto/Personal/Mortgage/Builder/Other): "); // Prompt the user to enter loan type
    String loanType;
    boolean validLoanType = false;

    while (!validLoanType) {
      loanType = input.nextLine().toLowerCase(); // Read loan type input and convert to lower case

      switch (loanType) {
      case "auto":
        loan = new AutoLoan(recordID, loanType, interestRate, TimeLeft, amountLeft); // Add into the Auto loan constructor
        validLoanType = true;
        break;
      case "builder":
        double overpaymentPercentageBuilder = 0;
        // Prompt the user to enter the over payment percentage for BuilderLoan
        while (true) {
          System.out.print("Enter overpayment percentage (between 0 and 2): ");
          if (input.hasNextDouble()) { // Check if the input is a valid double
            overpaymentPercentageBuilder = input.nextDouble();
            if (overpaymentPercentageBuilder >= 0 && overpaymentPercentageBuilder <= 2) { // Validate the input range
              break;
            } else {
              System.out.println("Invalid overpayment percentage. Must be between 0 and 2.");
            }
          } else {
            System.out.println("Invalid input. Please enter a valid number."); // Notify the user of invalid input
            input.next(); // Consume the invalid input to prevent an infinite loop
          }
        }
        input.nextLine(); // Consume the newline character
        loan = new BuilderLoan(recordID, loanType, interestRate, TimeLeft, amountLeft, overpaymentPercentageBuilder); // Add into the builder loan constructor
        validLoanType = true;
        break;
      case "mortgage":
        double overpaymentPercentageMortgage = 0;
        // Prompt the user to enter the over payment percentage for MortgageLoan
        while (true) {
          System.out.print("Enter overpayment percentage (between 0 and 2): ");
          if (input.hasNextDouble()) { // Check if the input is a valid double
            overpaymentPercentageMortgage = input.nextDouble();
            if (overpaymentPercentageMortgage >= 0 && overpaymentPercentageMortgage <= 2) { // Validate the input range
              break;
            } else {
              System.out.println("Invalid overpayment percentage. Must be between 0 and 2.");
            }
          } else {
            System.out.println("Invalid input. Please enter a valid number."); // Notify the user of invalid input
            input.next(); // Consume the invalid input to prevent an infinite loop
          }
        }
        input.nextLine(); // Consume the newline character
        loan = new MortgageLoan(recordID, loanType, interestRate, TimeLeft, amountLeft, overpaymentPercentageMortgage); // Add into the mortgage loan constructor
        validLoanType = true;
        break;
      case "personal":
        loan = new PersonalLoan(recordID, loanType, interestRate, TimeLeft, amountLeft); // Add into the builder loan constructor
        validLoanType = true;
        break;
      case "other":
        loan = new OtherLoan(recordID, loanType, interestRate, TimeLeft, amountLeft); // Add into the builder loan constructor
        validLoanType = true;
        break;
      default:
        System.out.println("Invalid loan type. Please enter a valid loan type (auto, builder, mortgage, personal, other)."); // Invalidate if user doesn't type of the five options
        System.out.print("Enter loan type: "); // Prompt again for loan type
        break;
      }
    }

    customer.addLoanRecord(loan);

    // Check the customer's eligibility status after adding the new credit record
    customer.setEligibilityStatus(customer.checkEligibility());
    System.out.println("Credit record added successfully.");
    registeredRecords++; // Increment registeredRecords count
  }

  // REMOVE LOAN RECORD 

  private static void removeLoanRecord() {
    System.out.print("Enter customer ID: ");
    String customerID = input.nextLine().toUpperCase(); // User enters CustomerID
    Customer customer = findCustomerID(customerID); // System finds the customerID
    if (customer == null) {
      System.out.println("Customer not found."); // System can't find the customerID
      return;
    }

    List < Loan > customerCreditRecords = customer.getcreditRecords(); // Retrieve the customer's loan records
    if (customerCreditRecords.isEmpty()) {
      System.out.println("Customer has no loans."); // Notify if the customer has no loans
      return;
    }

    System.out.println("Loan records for customer " + customerID + ":");
    System.out.println("=============================================================================");
    System.out.printf("%-10s%-10s%-15s%-15s%-10s%n", "Record ID", "Loan Type", "Interest Rate", "Amount Left", "Time Left");
    System.out.println("=============================================================================");
    for (Loan loan: customerCreditRecords) {
      System.out.printf("%-10s%-10s%-15.2f%-15.2f%-10d%n", loan.getRecordID(), loan.getLoanType(), loan.getInterestRate(),
        loan.getAmountLeft(), loan.getTimeLeft()); // Display loan details in a tabular format
    }
    System.out.println("=============================================================================");

    while (true) {
      System.out.print("Enter the loan record ID you want to remove: ");
      String loanIDToRemove = input.nextLine(); // User enters the recordID they want to remove

      boolean found = false; // Flag to indicate if the record ID is found
      for (int i = 0; i < customerCreditRecords.size(); i++) {
        Loan loan = customerCreditRecords.get(i);
        if (loan.getRecordID().equals(loanIDToRemove)) {
          customerCreditRecords.remove(i); // Remove the recordID if found
          System.out.println("Loan record ID " + loanIDToRemove + " removed successfully.");
          registeredRecords--;
          customer.setEligibilityStatus(customer.checkEligibility()); // Update eligibility status after removing a loan record
          found = true; // Set found = true
          break; // Exit the loop once the record is found and removed
        }
      }

      if (!found) {
        System.out.println("Loan record not found. Please enter a valid record ID."); // Notify if the record ID is not found
      } else {
        break; // Break out of the loop if the record is found and removed successfully
      }
    }
  }

  // UPDATE CUSTOMER INCOME

  private static void updateCustomerIncome() {
    System.out.print("Enter the customer ID: ");
    String customerID = input.nextLine().toUpperCase(); // User enters customerID 
    Customer customer = findCustomerID(customerID); // System finds the customerID user entered
    if (customer == null) {
      System.out.println("Customer not found.");
      return; // Return to the display menu if the system can't find the customerID
    }

    System.out.println("Update information for customer " + customerID); // Sends message that this customerID exists
    double newIncome = 0; // Initialise new income to 0
    boolean validIncome = false;
    while (!validIncome) {
      System.out.print("Enter new income (or press 'n' to keep the current value): ");
      String inputString = input.nextLine().trim(); // User types in their answer and trims leading/trailing whitespace
      if (inputString.equalsIgnoreCase("n")) { // User wants to keep the current value
        System.out.println("Income has not been changed...");
        validIncome = true;
      } else {
        try {
          newIncome = Double.parseDouble(inputString); // Multiply the income by 1000
          if (newIncome > 0) {
            customer.setIncome(newIncome * 1000); // Change into a new value
            customer.setEligibilityStatus(customer.checkEligibility());
            validIncome = true; // Breaks the loop when they enter a valid income
          } else {
            System.out.println();
            System.out.println("Invalid input. Please enter a positive number..."); // User entered a negative number
          }
        } catch (NumberFormatException e) { // Throw in error handling if user didn't type a number
          System.out.println();
          System.out.println("Invalid input. Please enter a valid number."); // User didn't enter a number 
        }
      }
    }
  }

  // UPDATE LOAN RECORD
  private static void updateLoanRecord() {
    System.out.print("Enter customer ID: ");
    String customerID = input.nextLine().toUpperCase(); // User enters customerID

    Customer customer = findCustomerID(customerID); // System finds the customerID
    if (customer == null) {
      System.out.println("Customer not found."); // System doesn't find the customerID so present a message
      return; // Return to the display menu
    }

    List < Loan > creditRecords = customer.getcreditRecords();
    if (creditRecords.isEmpty()) {
      System.out.println("No loan records found for this customer."); // Systems states that there are no records for customerID
      return; // Return to the display menu
    }

    // Print the table only if the customer has loan records
    System.out.println("Loan records for customer " + customerID + ":");
    System.out.println(" ====================================================================================================");
    System.out.println(String.format("%-15s%-15s%-30s%-20s%-25s", "Record ID", "Loan Type", "Amount Left (in thousands)", "Interest Rate (%)", "Loan Term Left (years)"));
    System.out.println(" =====================================================================================================");
    for (Loan loan: creditRecords) {
      System.out.println(String.format("%-15s%-15s%-30.2f%-20.2f%-25d", loan.getRecordID(), loan.getLoanType(), loan.getAmountLeft(), loan.getInterestRate(), loan.getTimeLeft()));
      System.out.println(" ======================================================================================================");
    }

    Loan loanToUpdate = null;
    String recordID;
    boolean found = false; // Initialise boolean found

    while (!found) {
      System.out.print("Enter the record ID of the loan you want to update: ");
      recordID = input.nextLine(); // User enters recordID

      for (Loan loan: creditRecords) { // System finds the recordID
        if (loan.getRecordID().equals(recordID)) {
          loanToUpdate = loan;
          found = true;
          break;
        }
      }

      if (!found) {
        System.out.println("Loan record with ID " + recordID + " not found. Please try again.");
      }
    }

    boolean validAmountLeft = false;
    while (!validAmountLeft) {
      System.out.print("Enter new amount left (or press 'n' to keep the current value): ");
      String newAmountLeftInput = input.nextLine().trim(); // User enters Amount Left
      if (newAmountLeftInput.equals("n")) {
        validAmountLeft = true; // User decides to keep the current value
      } else {
        try {
          double newAmountLeft = Double.parseDouble(newAmountLeftInput);
          if (newAmountLeft <= 0) { // User didn't put a positive value
            System.out.println("Invalid input. Amount left must be greater than 0.");
          } else {
            loanToUpdate.setAmountLeft(newAmountLeft * 1000); // Sets the newAmountLeft
            validAmountLeft = true; // Break loop
          }
        } catch (NumberFormatException e) {
          System.out.println("Invalid input. Please enter a valid number."); // User didn't enter a number
        }
      }
    }

    // Update loan term left
    boolean validTimeLeft = false;
    while (!validTimeLeft) {
      System.out.print("Enter new time left (or press 'n' to keep the current value): ");
      String newTimeLeftInput = input.nextLine().trim(); // User enters time left
      if (newTimeLeftInput.equals("n")) {
        validTimeLeft = true; // User decides to keep the current value
      } else {
        try {
          int newTimeLeft = Integer.parseInt(newTimeLeftInput);
          if (newTimeLeft <= 0) { // User didn't put a positive value
            System.out.println("Invalid input. Loan term left must be greater than 0.");
          } else {
            loanToUpdate.setTimeLeft(newTimeLeft);
            validTimeLeft = true; // Set new time left 
          }
        } catch (NumberFormatException e) {
          System.out.println("Invalid input. Please enter a valid integer."); // User didn't enter a number
        }
      }
    }

    // Update interest rate
    boolean validInterestRate = false;
    while (!validInterestRate) {
      System.out.print("Enter new interest rate (or press 'n' to keep the current value): ");
      String newInterestRateInput = input.nextLine().trim();
      if (newInterestRateInput.equals("n")) {
        validInterestRate = true; // User decides to keep the current value
      } else {
        try {
          double newInterestRate = Double.parseDouble(newInterestRateInput);
          if (newInterestRate <= 0) {
            System.out.println("Invalid input. Interest rate must be greater than 0."); // User didn't enter a number
          } else {
            loanToUpdate.setInterestRate(newInterestRate); // Set new interest rate 
            validInterestRate = true;
          }
        } catch (NumberFormatException e) {
          System.out.println("Invalid input. Please enter a valid number."); // User didn't type a number
        }
      }
    }

    // Update loan type
    boolean validLoanType = false;
    while (!validLoanType) {
      // Prompt user to enter new loan type
      System.out.print("Enter new loan type ((Auto/Personal/Mortgage/Builder/Other) or press 'n' to keep the current value): ");
      String newLoanType = input.nextLine().trim().toLowerCase();

      if (newLoanType.equals("n")) {
        // User decides to keep the current value by pressing 'n' or leaving it empty
        validLoanType = true;
      } else {
        switch (newLoanType) {
        case "auto":
        case "personal":
        case "other":
          if (loanToUpdate != null) {
            // Create a new loan object based on the selected loan type
            Loan newLoan;
            switch (newLoanType) {
            case "auto":
              // Update an AutoLoan object
              newLoan = new AutoLoan(loanToUpdate.getRecordID(), newLoanType, loanToUpdate.getInterestRate(), loanToUpdate.getTimeLeft(), loanToUpdate.getAmountLeft());
              break;
            case "personal":
              // Update to a PersonalLoan object
              newLoan = new PersonalLoan(loanToUpdate.getRecordID(), newLoanType, loanToUpdate.getInterestRate(), loanToUpdate.getTimeLeft(), loanToUpdate.getAmountLeft());
              break;
            case "other":
              // Update an OtherLoan object
              newLoan = new OtherLoan(loanToUpdate.getRecordID(), newLoanType, loanToUpdate.getInterestRate(), loanToUpdate.getTimeLeft(), loanToUpdate.getAmountLeft());
              break;
            default:
              throw new IllegalArgumentException("Invalid loan type.");
            }
            // Find the index of the loan to update and replace it with the new loan in the list
            int indexToUpdate = creditRecords.indexOf(loanToUpdate);
            creditRecords.remove(indexToUpdate); // remove old loan 
            creditRecords.add(indexToUpdate, newLoan); // add new loan
            // Set validLoanType to true to exit the loop
            validLoanType = true;
          } else {
            System.out.println("Invalid operation. No loan record selected.");
          }
          break;
        case "builder":
        case "mortgage":
          if (loanToUpdate != null) {
            double overpaymentPercentage = 0;
            try {
              // Get over payment percentage from user
              overpaymentPercentage = getOverpaymentPercentage(input);
              // Create a new loan object with the over payment percentage
              Loan newLoan;
              if (newLoanType.equals("builder")) {
                // Create a BuilderLoan object
                newLoan = new BuilderLoan(loanToUpdate.getRecordID(), newLoanType, loanToUpdate.getInterestRate(), loanToUpdate.getTimeLeft(), loanToUpdate.getAmountLeft(), overpaymentPercentage);
              } else {
                // Create a MortgageLoan object
                newLoan = new MortgageLoan(loanToUpdate.getRecordID(), newLoanType, loanToUpdate.getInterestRate(), loanToUpdate.getTimeLeft(), loanToUpdate.getAmountLeft(), overpaymentPercentage);
              }
              // Find the index of the loan to update and replace it with the new loan in the list
              int indexToUpdate = creditRecords.indexOf(loanToUpdate);
              creditRecords.remove(indexToUpdate);
              creditRecords.add(indexToUpdate, newLoan);
              // Set validLoanType to true to exit the loop
              validLoanType = true;
            } catch (NumberFormatException e) {
              System.out.println("Invalid input for overpayment percentage. Please enter a valid number.");
            } catch (IllegalArgumentException e) {
              System.out.println(e.getMessage());
            }
          } else {
            System.out.println("Invalid operation. No loan record selected.");
          }
          break;
        default:
          System.out.println("Invalid loan type. Please enter a valid loan type (auto, personal, builder, mortgage, other).");
          break;
        }
      }
    }

    System.out.println("Loan record updated successfully."); // Message to user that it has been completed
  }

  //PRINT SPECIFIC CUSTOMER DETAILS 
  private static void printCustomerDetails() {
    // Prompting the user to enter the customer ID
    System.out.print("Enter customer ID: ");
    String customerID = input.nextLine().toUpperCase(); // Getting customer ID input and converting to upper case

    Customer customer = findCustomerID(customerID); // Finding the customer based on the entered ID
    if (customer == null) {
      System.out.println("Customer not found.");
      return; // If customer not found, display a message and return to display menu
    }

    // Displaying the details of the specific customer
    System.out.println("Customer ID: " + customer.getCustomerID());
    List < Loan > creditRecords = customer.getcreditRecords();
    if (creditRecords.isEmpty()) {
      // If no loan records found for the customer, display a message
      System.out.println("No loan records found for this customer.");
    } else {
      // If loan records found, display the details in a formatted table
      System.out.println("Loan Records:");
      System.out.println(" ====================================================================================================");
      System.out.println(String.format("%-15s%-15s%-30s%-20s%-25s", "Record ID", "Loan Type", "Amount Left (in thousands)", "Interest Rate (%)", "Loan Term Left (years)"));
      System.out.println(" =====================================================================================================");
      for (Loan loan: creditRecords) {
        System.out.println(String.format("%-15s%-15s%-30.2f%-20.2f%-25d", loan.getRecordID(), loan.getLoanType(), loan.getAmountLeft(), loan.getInterestRate(), loan.getTimeLeft()));
        System.out.println(" ======================================================================================================");
      }
    }
  }

  //PRINT ALL CUSTOMER DETAILS
  private static void printAllCustomerDetails() {
    if (customers.isEmpty()) {
      // If no customers are registered, display a message and return
      System.out.println("No customers registered yet.");
      return; // Return to the display menu
    }

    // Displaying details of all registered customers
    System.out.println("All Customer Details:");
    System.out.println("MAX RECORD: " + maxRecords);
    System.out.println("REGISTERED RECORD: " + registeredRecords);
    System.out.println();

    for (Customer customer: customers) {
      // Looping through each customer and printing their details
      System.out.println("Customer ID: " + customer.getCustomerID());
      System.out.println("Income: " + customer.getIncome());
      System.out.println("Eligible to arrange new loans - " + (customer.getEligibilityStatus() ? "YES" : "NO"));
      System.out.println("Loan Records:");

      List < Loan > creditRecords = customer.getcreditRecords();
      if (creditRecords.isEmpty()) {
        // If no loan records found for the customer, display a message
        System.out.println("No loan records found for this customer.");
      } else {
        // If loan records found, display the details in a formatted table
        System.out.println(" ====================================================================================================");
        System.out.println(String.format("%-15s%-15s%-30s%-20s%-25s", "Record ID", "Loan Type", "Amount Left (in £1000s)", "Interest Rate (%)", "Loan Term Left (years)"));
        System.out.println(" =====================================================================================================");

        for (Loan loan: creditRecords) {
          System.out.println(String.format("%-15s%-15s%-30.2f%-20.2f%-25d", loan.getRecordID(), loan.getLoanType(), loan.getAmountLeft(), loan.getInterestRate(), loan.getTimeLeft()));
          System.out.println(" ======================================================================================================");
        }
      }

      System.out.println();
    }
  }

  //Method to find a customer by their ID
  private static Customer findCustomerID(String customerID) {
    // Loop through the list of customers to find the one with the matching ID
    for (Customer customer: customers) {
      if (customer.getCustomerID().equals(customerID)) {
        return customer; // Return the customer if found
      }
    }
    return null; // Return null if customer not found
  }

  //Method to generate a unique record ID for a loan
  private static String generateRecordID() {
    int recordID;
    do {
      recordID = random.nextInt(900000) + 100000; // Generate a random 6-digit number
    } while (generatedNumbers.contains(recordID)); // Ensure the generated ID is unique

    generatedNumbers.add(recordID); // Add the generated ID to the list of used IDs
    return String.format("%06d", recordID); // Format the generated ID to ensure it has 6 digits
  }

  //Method to validate a customer ID based on a specific pattern
  private static boolean isValidCustomerID(String customerID) {
    return customerID.matches("[A-Za-z]{3}\\d{3}"); // Check if the customer ID matches the pattern
  }

  //Method to get the over payment percentage from user input
  private static double getOverpaymentPercentage(Scanner input) {
    double overpaymentPercentage = 0;
    while (true) {
      // Prompt the user to enter the over payment percentage
      System.out.print("Enter overpayment percentage (between 0 and 2): ");
      String percentageInput = input.nextLine();
      try {
        overpaymentPercentage = Double.parseDouble(percentageInput); // Parse the input as a double
        if (overpaymentPercentage >= 0 && overpaymentPercentage <= 2) {
          break; // Break out of the loop if the input is valid
        } else {
          System.out.println("Invalid overpayment percentage. Must be between 0 and 2.");
        }
      } catch (NumberFormatException e) {
        System.out.println("Invalid input. Please enter a valid number."); // Handle invalid input
      }
    }
    return overpaymentPercentage; // Return the validated over payment percentage
  }
}

