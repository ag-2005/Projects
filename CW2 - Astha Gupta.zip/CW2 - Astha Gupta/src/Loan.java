public abstract class Loan { // ABSTRACT LOAN CLASS
  // Attributes of a loan - protected so that it can be accessed from subclasses within the same package
  protected String recordID; // Unique identifier for the loan
  protected String loanType; // Type of the loan
  protected double interestRate; // Interest rate of the loan
  protected int TimeLeft; // Time left for the loan in years
  protected double amountLeft; // Amount left to be paid for the loan

  // Constructor to initialise loan details 
  public Loan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft) {
    this.recordID = recordID;
    this.loanType = loanType;
    this.interestRate = interestRate;
    this.TimeLeft = TimeLeft; 
    this.amountLeft = amountLeft;
  }

  // Getter methods for these loan attributes
  public String getRecordID() {
    return recordID;
  }

  public String getLoanType() {
    return loanType;
  }

  public double getInterestRate() {
    return interestRate;
  }

  public double getAmountLeft() {
    return amountLeft;
  }

  public int getTimeLeft() {
    return TimeLeft;
  }

  // Setter methods for these loan attributes
  public void setAmountLeft(double amountLeft) {
    this.amountLeft = amountLeft;
  }

  public void setLoanType(String loanType) {
    this.loanType = loanType;
  }

  public void setTimeLeft(int TimeLeft) {
    this.TimeLeft = TimeLeft;
  }

  public void setInterestRate(double interestRate) {
    this.interestRate = interestRate;
  }

  // abstract method to check eligibility of a loan for a customer
  public abstract boolean checkEligibility(Customer customer);
}

// Sub class representing an Auto Loan
class AutoLoan extends Loan {
  public AutoLoan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft) {
    super(recordID, loanType, interestRate, TimeLeft, amountLeft);
  }

  // abstract method to check eligibility
  @Override
  public boolean checkEligibility(Customer customer) {
    double totalAmountLeftToPay = customer.getTotalAmountLeftToPay();
    double annualIncome = customer.getIncome() * 4; // Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome;
  }
}

// Sub class representing a Builder Loan
class BuilderLoan extends Loan implements OverpayableLoan {
  private double overpaymentPercentage; //  returns over payment 

  public BuilderLoan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft, double overpaymentPercentage) {
    super(recordID, loanType, interestRate, TimeLeft, amountLeft);
    this.overpaymentPercentage = overpaymentPercentage;
  }

  // abstract method to check eligibility
  @Override
  public boolean checkEligibility(Customer customer) {
    double totalAmountLeftToPay = customer.getTotalAmountLeftToPay();
    double annualIncome = customer.getIncome() * 4; // Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome;
  }

  // Implementation of the method to get the over payment percentage
  @Override
  public double getOverpaymentPercentage() {
    return overpaymentPercentage; //return over payment
  }
}

//Sub class representing a Mortgage Loan
class MortgageLoan extends Loan implements OverpayableLoan {
  private double overpaymentPercentage; // Percentage by which the loan can be over paid

  public MortgageLoan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft, double overpaymentPercentage) {
    super(recordID, loanType, interestRate, TimeLeft, amountLeft);
    this.overpaymentPercentage = overpaymentPercentage;
  }

  // abstract method to check eligibility
  @Override
  public boolean checkEligibility(Customer customer) {
    double totalAmountLeftToPay = customer.getTotalAmountLeftToPay();
    double annualIncome = customer.getIncome() * 4; // Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome;
  }

  // Implementation of the method to get the over payment percentage
  @Override
  public double getOverpaymentPercentage() {
    return overpaymentPercentage; // returns over payment 
  }
}

// Sub class for personal loan
class PersonalLoan extends Loan {
  public PersonalLoan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft) {
    super(recordID, loanType, interestRate, TimeLeft, amountLeft);
  }

  //abstract method to check eligibility
  @Override
  public boolean checkEligibility(Customer customer) {
    double totalAmountLeftToPay = customer.getTotalAmountLeftToPay();
    double annualIncome = customer.getIncome() * 4; // Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome; // check total amount left is greater than annual income
  }
}

//Sub class representing an Other Loan
class OtherLoan extends Loan {
  public OtherLoan(String recordID, String loanType, double interestRate, int TimeLeft, double amountLeft) {
    super(recordID, loanType, interestRate, TimeLeft, amountLeft);
  }

  //abstract method to check eligibility
  @Override
  public boolean checkEligibility(Customer customer) {
    // Implement eligibility criteria for Other Loan
    double totalAmountLeftToPay = customer.getTotalAmountLeftToPay();
    double annualIncome = customer.getIncome() * 4; // Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome;
  }
}

//interface for loans that can be overpaid
interface OverpayableLoan {
double getOverpaymentPercentage(); // Method to get the over payment percentage for the loan
}