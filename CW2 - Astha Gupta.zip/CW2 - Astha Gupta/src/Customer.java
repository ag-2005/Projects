import java.util.ArrayList;
import java.util.List;

// PUBLIC CLASS - CUSTOMER CLASS
public class Customer {
  // attributes are private
  private String customerID; // Unique customerID
  private double income; // Income of the customer
  private boolean eligibilityStatus; // Eligibility status for customer 
  private List < Loan > creditRecords; // List to store credit records

  //Constructor to initialise customer details
  public Customer(String customerID, double income) {
    this.customerID = customerID;
    this.income = income;
    this.eligibilityStatus = false; // Initilise the customer is not eligible
    this.creditRecords = new ArrayList < > (); // Initialise the list of credit records
  }

  //Getter method for customer ID
  public String getCustomerID() {
    return customerID;
  }

  //Getter method for income
  public double getIncome() {
    return income;
  }

  //Setter method for income
  public void setIncome(double income) {
    this.income = income;
  }

  //Method to check eligibility based on the customer's total amount left to pay and income
  public boolean checkEligibility() {
    double totalAmountLeftToPay = getTotalAmountLeftToPay();
    double annualIncome = getIncome() * 4; //Calculate 4 times the annual income

    return totalAmountLeftToPay <= annualIncome; // Return true if the total amount left to pay is less than or equal to 4 times the annual income
  }

  //Getter method for eligibility status
  public boolean getEligibilityStatus() {
    return eligibilityStatus;
  }

  //Setter method for eligibility status
  public void setEligibilityStatus(boolean eligibilityStatus) {
    this.eligibilityStatus = eligibilityStatus;
  }

  //Method to calculate the total amount across all credit records
  public double getTotalAmountLeftToPay() {
    double totalAmountLeft = 0.0;
    if (creditRecords != null) {
      for (Loan loan: creditRecords) {
        totalAmountLeft += loan.getAmountLeft();
      }
    }
    return totalAmountLeft;
  }

  // Method to add a loan record to the records
  public void addLoanRecord(Loan loan) {
    creditRecords.add(loan);
  }

  // Getter method for credit records
  public List < Loan > getcreditRecords() {
    return creditRecords;
  }

  // Method to remove a loan record from the records based on the record ID
  public boolean removeLoanRecord(String recordID) {
    //Go through the list to match recordID
    for (int i = 0; i < creditRecords.size(); i++) {
      Loan loan = creditRecords.get(i);
      if (loan.getRecordID().equals(recordID)) {
        creditRecords.remove(i); // Remove the loan from the list
        return true; // Loan record removed successfully
      }
    }
    return false; // Loan record not found
  }
}