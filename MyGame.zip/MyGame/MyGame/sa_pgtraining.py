'''
Pygame training tools

This module handles some of the more complex parts of pygame,
providing helper functions for the purpose of training those who are new to programming.


This module is to be used only as part of Software Academy classes,
in classes run by Software Academy staff, or non-commercially.
For information and permissions, please contact me at
m.stickler@softwareacademy.co.uk
or the director of the centre at ali@softwareacademy.co.uk

@author Michael Stickler

'''

import math
import os

import pygame as pg
import random



# define colours so they are easier to use
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
ORANGE = (255, 128, 0)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
PURPLE = (200, 0, 255)


class Sprite(pg.sprite.Sprite):
    '''base sprite class'''

    def __init__(self, controller, **kwargs):
        super(Sprite, self).__init__()

        x_pos = kwargs.setdefault("xpos", 0)
        y_pos = kwargs.setdefault("ypos", 0)

        visible = kwargs.setdefault("visible", True)
        self.animated = kwargs.setdefault("animated", False)
        self.controller = controller
        self.collision = kwargs.setdefault("collisiongroups", [])

        for grp in ["all"] + self.collision:
            if grp not in self.controller.collision_groups:
                self.controller.collision_groups[grp] = pg.sprite.Group()

            self.controller.collision_groups[grp].add(self)
        self.debug = kwargs.setdefault("debug", False)
        self.image_file = None
        self.image_fill = None
        self.image_sheet = None
        self.image_width = 0
        self.image_height = 0
        self.image_angle = 0
        self.image_scale = 1
        self.image_sequence = []
        self.image_frame = 0.0
        self.enable_tra = True
        self.image_digits = 0
        self.masked = True
        # self.mask_file = None
        self.mask = None
        self.mask_update_rotate = True
        self.mask_update_scale = True
        self.mask_update_anim = True
        self.mask_update_image = True
        self.image_setup()
        self.create_event()


        # these variables are used internally to check if the mask needs updating
        self._image_angle_last = self.image_angle
        self._image_scale_last = self.image_scale
        self._image_frame_last = self.image_frame
        self._image_sequence_last = self.image_sequence

        if self.image_file is not None:
            # if using imagefile

            #===================================================================
            # Formatting
            #===================================================================
            if isinstance(self.image_file, list):
                path = os.path.join(*self.image_file)
            elif isinstance(self.image_file, str):
                path = self.image_file
            else:
                raise TypeError(
                    "Image is not a valid type ({}). Use a string path or a path separated into a list.".format(type(self.image_file)))

            #===================================================================
            # Loading
            #===================================================================
            if "{}" in path:
                self.image_sequence = get_animation(path, self.image_digits)
            else:
                self.image_sequence = [pg.image.load(path).convert_alpha()]

        elif self.image_fill is not None:
            # if using image fill
            self.image_sequence = [pg.surface.Surface((self.image_width,
                                                       self.image_height)).convert_alpha()]

            self.image_sequence[0].fill(self.image_fill)
        elif not self.image_sequence:
            # if not specified
            self.image_sequence = [pg.surface.Surface((self.image_width,
                                                       self.image_height)).convert_alpha()]
            self.image_sequence[0].fill(RED)

        # set to frame
        # self.orig_image = pg.surface.Surface([128, 64]).convert_alpha()
        # self.orig_image.fill(RED)
        self.orig_image = self.image_sequence[int(self.image_frame % len(self.image_sequence))]


        self.rect = self.orig_image.get_rect()
        # if self.enable_tra:
        self.image = pg.transform.rotozoom(self.orig_image,
                                           self.image_angle,
                                           self.image_scale)
        self.rect = self.image.get_rect(center=self.rect.center)
        if self.masked:
            self.mask = pg.mask.from_surface(self.image, 127)
        #=======================================================================
        # self.mask_file
        # if self.mask_file is not None:
        #     self.mask = pg.mask.from_surface(pg.image.load(get_path(self.mask_file)).convert_alpha(), 127)
        #=======================================================================


        self.rect.x = x_pos
        self.rect.y = y_pos

        self.controller.all_sprites.add(self)
        if visible:
            self.controller.visible_sprites.add(self)



    def update(self):
        '''
        This function is called by the all_sprites group in the controller,
        It calls the update event on the sprite, which can be overwritten.
        It also refreshes the sprite image, if the update event changed it.
        '''
        self.update_event()
        self.refresh()

    def refresh(self):
        '''
        This function refreshes the image of the sprite if it has been changed.
        It may be necessary to call this from another object if any other object changes it's image
        '''
        # self.orig_image = pg.surface.Surface([128, 64]).convert_alpha()
        # self.orig_image.fill(RED)
        self.orig_image = self.image_sequence[int(self.image_frame % len(self.image_sequence))]
        # if self.enable_tra:
        # rotate sprite
        self.image = pg.transform.rotozoom(
            self.orig_image, self.image_angle, self.image_scale)
        # if not self.rect.width == self.rect.height:
        self.rect = self.image.get_rect(center=self.rect.center)

    def create_event(self):
        '''Event will be called when sprite has been initialised,
        replace this with code that would go in __init__,
        so no super call is needed (no need to explain what super is)'''
        self.image_file = None
        self.image_fill = None
        self.image_width = 32
        self.image_height = 32

    def image_setup(self):
        ''' DEPRECIATED (partially)
        imagesetup and create_event combined, older games still use it.
        set up image, override to set sprite image'''
        self.image_file = None
        self.image_fill = None
        self.image_width = 32
        self.image_height = 32

    def update_event(self):
        '''Event called when sprite us updated, replace this.'''
        pass

    def get_collisions(self, group="all", **kwargs):
        '''
        check for collisions between this sprite and any sprites in the specified collision group.
        If none specified, will check for collisions against all groups.
        Returns a list of all sprites collided.

        Example:

        collisions = self.controller.get_collisions("testGroup")

        if collisions:
            print("collided with something")

        for obj in collisions:
            print("Collided with", obj)
        '''

        masked = kwargs.setdefault("mask", False)
        if group not in self.controller.collision_groups:
            self.controller.collision_groups[group] = pg.sprite.Group()
        collisions = pg.sprite.spritecollide(self,
                                       self.controller.collision_groups[group],
                                       False)
        if collisions and masked:
            self.update_mask()
            masked_collisions = []
            if self.mask is None:
                self.mask = pg.mask.from_surface(self.image, 127)

            for col in collisions:
                if col.mask is None:
                    col.mask = pg.mask.from_surface(col.image, 127)

                detect = pg.sprite.collide_mask(self, col)
                if detect is not None:
                    masked_collisions.append(detect)
            collisions = masked_collisions
        return collisions
    def update_mask(self):
        # FIXME: update not happening with fill objects
        if self.mask_update_rotate and not self.image_angle == self._image_angle_last:
            self.mask = pg.mask.from_surface(self.image, 127)
        elif self.mask_update_scale and not self.image_scale == self._image_scale_last:
            self.mask = pg.mask.from_surface(self.image, 127)
        elif self.mask_update_anim and not int(self.image_frame) == int(self._image_frame_last):
            self.mask = pg.mask.from_surface(self.image, 127)
        elif self.mask_update_image and not self.image_sequence == self._image_sequence_last:
            self.mask = pg.mask.from_surface(self.image, 127)
    def set_image(self, **kwargs):
        '''
        repeats the image setup process for a new image.

        This is not necessary for spritesheets,
        just use

            imageSequence = sheet.get_sprite(...)

        instead
        '''
        colour = kwargs.setdefault("colour", None)
        image = kwargs.setdefault("image", None)
        animation = kwargs.setdefault("animation", None)
        width = kwargs.setdefault("width", 16)
        height = kwargs.setdefault("height", 16)
        min_digits = kwargs.setdefault("mindigits", 1)

        if colour is not None:
            self.image_sequence = [pg.surface.Surface(
                (width, height)).convert_alpha()]
            self.image_sequence[0].fill(colour)
        if image is not None:
            self.image_sequence = [pg.image.load(get_path(image)).convert_alpha()]
        if animation is not None:
            self.image_sequence = get_animation(animation, min_digits)


class SpriteSheet(object):
    '''
    Spritesheet class, load image containing multiple sprites.
    Then, the get_sprite method can be used to grab sprites from it.

    Recommended to be used as a global variable, empty at first, as pygame will not have loaded.:

        SPRITESHEET_NAME = None

    then load the files at the top of the game_start method of the controller class:

    def game_start(self):
        SPRITESHEET_NAME = pgt.SpriteSheet(["filepath", "file"])
    '''
    def __init__(self, image_file):
        file_path = get_path(image_file)
        # load image
        self.sheet = pg.image.load(file_path).convert_alpha()
        # get image width/height

    def get_sprite(self, origin_x, origin_y, width, height, **kwargs):
        '''
        get a sprite image sequence from the spritesheet.

        PARAMETERS
        ----------
        origin x and y: int
            top left corner of first frame in animation.

        width and height: int
            width and height of the sprite

        OPTIONAL
        --------
        padding_x and y: int
            ammount of space to leave between frames, if sprite sheet has gaps, can be negative
            defaults to 0

        direction: str ("h" or "v")
            direction of animation laid out in sheet. Some sheets have animations aligned vertically
            defaults to "h"

        frames: int
            number of frames to load into image sequence, this is the length of the animation.
            defaults to 1

        RETURNS
        -------
        image_sequence: list of surfaces (animation or single frame)

        NOTES
        -----
        too few public methods, but currently useful to prevent needing to load images over and over
        '''
        padding_x = kwargs.setdefault("paddingx", 0)
        padding_y = kwargs.setdefault("paddingy", 0)
        direction = kwargs.setdefault("direction", "h")
        frames = kwargs.setdefault("frames", 1)
        image_sequence = []
        frame_x = origin_x
        frame_y = origin_y
        for _ in range(frames):
            # get image
            frame = pg.surface.Surface((width, height), pg.SRCALPHA)
            frame.blit(self.sheet, (0, 0), (frame_x, frame_y, width, height))
            image_sequence.append(frame)
            # wrap around edge (count x images)
            # error checking
            if direction == "h":
                frame_x += width + padding_x
            elif direction == "w":
                frame_y += height + padding_y
        return image_sequence


class Sound(pg.mixer.Sound):
    '''
    currently just inherits directly from pygame, as pygame sounds are fairly simple to use.
    only change made is to pass the file path through our get_path function

    NOTES
    -----
    too few public methods.
    could potentially just replace this with a function
    '''
    def __init__(self, sound_file):
        super(Sound, self).__init__(get_path(sound_file))


class Background:
    '''
    background images can be loaded and tiled, backgrounds will by default always appear behind other objects
    '''
    def __init__(self, controller, image, xtile=True, ytile=True, xoffset=0, yoffset=0):
        self.controller = controller
        self.xoffset = xoffset
        self.yoffset = yoffset
        self.image = pg.image.load(get_path(image)).convert_alpha()
        self.rect = self.image.get_rect()
        self.xtile = xtile
        self.ytile = ytile

        if self.xtile:
            self.xreps = int(self.controller.width / self.rect.width) + 1
        else:
            self.xreps = 1

        if self.ytile:
            self.yreps = int(self.controller.height / self.rect.height) + 1
        else:
            self.yreps = 1

        self.controller.backgrounds.append(self)

    def kill(self):
        self.controller.backgrounds.remove(self)

    def draw(self):
        # calculate offset
        if self.xtile:
            xo = math.copysign(abs(self.xoffset) % self.rect.width, self.xoffset)
        else:
            xo = self.xoffset

        if self.ytile:
            yo = math.copysign(abs(self.yoffset) % self.rect.height, self.yoffset)
        else:
            yo = self.yoffset

        for ix in range(self.xreps):
            for iy in range(self.yreps):
                xpos = xo + ix * self.rect.width
                ypos = yo + iy * self.rect.height
                self.controller.display.blit(self.image, (xpos, ypos))
        if self.xtile:
            for iy in range(self.yreps):
                # left
                xpos = xo + -1 * self.rect.width
                ypos = yo + iy * self.rect.height
                self.controller.display.blit(self.image, (xpos, ypos))

                # right
                xpos = xo + self.controller.width
                ypos = yo + iy * self.rect.height
                self.controller.display.blit(self.image, (xpos, ypos))

        if self.ytile:
            for ix in range(self.xreps):
                # top
                xpos = xo + ix * self.rect.width
                ypos = yo + -1 * self.rect.height
                self.controller.display.blit(self.image, (xpos, ypos))

                # right
                xpos = xo + ix * self.rect.width
                ypos = yo + self.controller.height
                self.controller.display.blit(self.image, (xpos, ypos))

        if self.xtile and self.ytile:
            self.controller.display.blit(self.image, (xo - self.rect.width, yo - self.rect.height))
            self.controller.display.blit(self.image, (xo - self.rect.width, yo + self.controller.height))
            self.controller.display.blit(self.image, (xo + self.controller.width, yo + self.controller.height))
            self.controller.display.blit(self.image, (xo + self.controller.width, yo - self.rect.height))


class Text():
    def __init__(self, controller, **kwargs):

        self.text = kwargs.setdefault("text", "")
        self.x = kwargs.setdefault("x", 0)
        self.y = kwargs.setdefault("y", 0)
        self.colour = kwargs.setdefault("colour", (0, 0, 0))
        self.controller = controller
        self.controller.texts.append(self)
        self.font = kwargs.setdefault("font", "default")
        self.textSurface = self.controller.fonts[self.font].render(
            str(self.text), True, self.colour)
        self.create_event()
        self.refresh()

    def refresh(self):
        self.textSurface = self.controller.fonts[self.font].render(
            str(self.text), True, self.colour)

    def draw(self):
        self.controller.display.blit(self.textSurface, (self.x, self.y))

    def create_event(self):
        pass

    def update_event(self):
        pass
    def kill(self):
        try:
            self.controller.texts.remove(self)
        except:
            pass
            # print(self.controller.texts)
        del self


class ParticleSystem():
    def __init__(self, controller):
        self.particles = []
        self.controller = controller
        self.controller.particle_systems.append(self)

    def create_particle(self, particle_type, x_pos, y_pos, **kwargs):
        particle = particle_type.get_particle()

        particle["xpos"] = x_pos
        particle["ypos"] = y_pos
        particle["imageindex"] = 0

        direction_random = (random.random() - 0.5) * kwargs.setdefault("directionrandom", 0.0)
        particle["direction"] = kwargs.setdefault("direction", 0.0) + direction_random

        speed_random = ((random.random()) * kwargs.setdefault("speedrandom", 0.0))
        particle["speed"] = kwargs.setdefault("speed", 0.0) + speed_random

        particle["gravity"] = kwargs.setdefault("gravity", particle["gravity"])
        particle["gravitydirection"] = kwargs.setdefault("gravitydirection", particle["gravitydirection"])

        particle["friction"] = kwargs.setdefault("friction", particle["friction"])

        life_random = ((random.random()) * kwargs.setdefault("liferandom", particle["liferandom"]))
        particle["life"] += life_random

        self.particles.append(particle)

    def update(self):
        self._particle_movement()
        for i, particle in enumerate(self.particles):
            particle["imageindex"] += 1
            particle["life"] -= 1
            if particle["life"] <= 0:
                del(self.particles[i])

    def add_emitter(self, **kwargs):
        return ParticleEmitter(self, **kwargs)

    def _particle_movement(self):
        for particle in self.particles:
            # friction
            particle["speed"] -= particle["friction"]
            if particle["speed"] < 0:
                particle["speed"] = 0
            # gravity
            x_speed = particle["speed"] * math.cos(math.radians(particle["direction"]))
            y_speed = particle["speed"] * math.sin(math.radians(particle["direction"]))
            x_speed += particle["gravity"] * math.cos(math.radians(particle["gravitydirection"]))
            y_speed += particle["gravity"] * math.sin(math.radians(particle["gravitydirection"]))

            particle["speed"] = math.sqrt(x_speed ** 2 + y_speed ** 2)
            particle["direction"] = math.degrees(math.atan2(y_speed , x_speed))


            particle["xpos"] += math.cos(math.radians(particle["direction"])) * particle["speed"]
            particle["ypos"] += math.sin(math.radians(particle["direction"])) * particle["speed"]

    def draw(self):
        for particle in self.particles:
            image = particle["image"][particle["imageindex"] % len(particle["image"])]
            self.controller.display.blit(image, (particle["xpos"], particle["ypos"]))

class ParticleEmitter():
    def __init__(self, psystem, **kwargs):
        self.psystem = psystem
        self.x_pos = kwargs.setdefault("xpos", 0)
        self.y_pos = kwargs.setdefault("ypos", 0)
        self.direction = kwargs.setdefault("direction", 0)
        self.direction_random = kwargs.setdefault("directionrandom", 0)
        self.speed = kwargs.setdefault("speed", 0)
        self.speed_random = kwargs.setdefault("speedrandom", 0)

        self.circle = kwargs.setdefault("circle", None)
        self.rectangle = kwargs.setdefault("rectangle", None)

    def _choose_position(self):
        if self.circle is not None:
            distance = math.sqrt(random.random()) * self.circle
            angle = random.random() * 360
            return (self.x_pos + distance * math.cos(math.radians(angle)), self.y_pos + distance * math.sin(math.radians(angle)))
        if self.rectangle is not None:
            return (self.x_pos + (random.random() - 0.5) * self.rectangle[0], self.y_pos + (random.random() - 0.5) * self.rectangle[1])


        return (self.x_pos, self.y_pos)
    def emit(self, particle, num, **kwargs):

        if 0.0 < num < 1.0:
            if random.random() < num:
                num = 1
        for i in range(int(num)):
            pos = self._choose_position()
            self.psystem.create_particle(particle, pos[0], pos[1],
                                         direction=self.direction,
                                         directionrandom=self.direction_random,
                                         speed=self.speed,
                                         speedrandom=self.speed_random,
                                         **kwargs)
class Particle():
    def __init__(self, **kwargs):
        # image
        image = kwargs.setdefault("image", [])
        image_sequence = kwargs.setdefault("imagesequence", [])
        if image_sequence:
            self.image_sequence = image_sequence
        elif image:
            self.image_sequence = get_image_sequence(image)
        else:
            # set as default red colour
            self.image_sequence = [pg.surface.Surface(
                (16, 16))]
            self.image_sequence[0].fill(RED)

        # values
        self.direction = kwargs.setdefault("direction", 0)
        self.speed = kwargs.setdefault("speed", 0)
        self.life = kwargs.setdefault("life", 30)
        self.life_random = kwargs.setdefault("liferandom", 15)
        self.gravity = kwargs.setdefault("gravity", 0.4)
        self.gravity_direction = kwargs.setdefault("gravitydirection", 90)
        self.friction = kwargs.setdefault("friction", 0.0)
    def get_particle(self):
        part_dict = {"image":self.image_sequence,
                     "direction":self.direction,
                     "speed":self.speed,
                     "life":self.life,
                     "liferandom":self.life_random,
                     "gravity": self.gravity,
                     "gravitydirection": self.gravity_direction,
                     "friction": self.friction}
        return part_dict

class GameController():
    '''main game controller, runs game and draws to screen'''

    def __init__(self, **kwargs):
        '''set up variables'''
        self.debug = kwargs.setdefault("debug", False)
        self.width = kwargs.setdefault("width", 800)
        self.height = kwargs.setdefault("height", 600)
        self.fps = kwargs.setdefault("fps", 30)
        self.col_grp = ["all"] + kwargs.setdefault("collisiongroups", [])

        self.collision_groups = {}
        self.caption = kwargs.setdefault("caption", "My Game")
        self.framerate = 0
        self.clock = pg.time.Clock()
        self.running = False
        self.paused = False
        self.backgrounds = []

        self.run_game()


    def run_game(self):
        '''set up pygame and launch game loop'''
        # launch pygame
        pg.init()

        # set up display
        self.display = pg.display.set_mode((self.width, self.height))
        pg.display.set_caption(self.caption)

        # set up groups
        self.all_sprites = pg.sprite.Group()
        self.visible_sprites = pg.sprite.Group()
        self.texts = []
        self.particle_systems = []

        self.collision_groups = {}

        for grp in self.col_grp:
            self.collision_groups[grp] = pg.sprite.Group()

        # get initial inputs
        self.input = pg.key.get_pressed()
        self.input_last = self.input
        self.fonts = {}
        self.new_font("couriernew", name="default")
        self.font_setup()
        self.fps_surface = self.fonts["default"].render("FPS: {}".format(self.framerate), True, RED)
        self.game_start()

        self.running = True
        while self.running:
            # wait for next frame
            self.clock.tick(self.fps)
            self.framerate = self.clock.get_fps()

            # get keyboard inputs
            self.input_last = self.input
            self.input = pg.key.get_pressed()

            # get just pressed and just released
            self.input_start = tuple(
                k and not l for k, l in list(zip(self.input, self.input_last)) if not l
            )

            self.input_end = tuple(
                l and not k for k, l in list(zip(self.input, self.input_last)) if not k
            )

            # check close input
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    self.running = False
            if pg.key.get_pressed()[pg.K_ESCAPE]:
                self.running = False

            if not self.paused:
                # update sprites
                self.update()
                self.draw()
            else:
                self.pause_update()
        pg.quit()

    def font_setup(self):
        pass

    def game_start(self):
        '''runs when the game starts, create objects etc.'''
        pass
    def update_event(self):
        pass
    def update(self):
        self.update_event()
        # update visible sprites
        self.all_sprites.update()
        # update all particles
        for p in self.particle_systems:
            p.update()

        # update texts (not text content)
        for text in self.texts:
            text.update_event()

    def pause_update(self):
        '''will run when game is paused, can be used to draw menu, game over, or unpause for example.'''
        pass

    def draw(self):
        # clear the screen to BLACK
        self.display.fill(BLACK)

        # draw all backgrounds
        for background in self.backgrounds:
            background.draw()
        # draw all visible sprites
        self.visible_sprites.draw(self.display)

        # draw particles
        for p in self.particle_systems:
            p.draw()
        # draw all text
        for text in self.texts:
            text.draw()

        # debug draw
        if self.debug:
            self.fps_surface = self.fonts["default"].render("FPS: {}".format(int(self.framerate)), True, RED)
            self.display.blit(self.fps_surface, (0, 0))
            for sprite in self.all_sprites.sprites():
                pg.draw.rect(self.display, WHITE, sprite.rect, 1)
                if sprite.mask is not None:
                    rects = sprite.mask.get_bounding_rects()
                    for rect in rects:
                        rectoffset = rect
                        rectoffset.center = sprite.rect.center
                        pg.draw.rect(self.display, RED, rectoffset, 1)
        # display everything we drew on our display onto our screen
        pg.display.flip()

    def quit(self):
        self.running = False

    def get_input(self, key, check):

        if check == "press":
            return self.input[key]
        elif check == "start":
            return self.input_start[key]
        elif check == "end":
            return self.input_end[key]

    def new_font(self, font, **kwargs):
        load = kwargs.setdefault("load", False)
        name = kwargs.setdefault("name", None)
        size = kwargs.setdefault("size", 16)
        bold = kwargs.setdefault("bold", False)
        italic = kwargs.setdefault("italic", False)

        if load:
            # if image file provided as list, os path it
            if type(font) is list:
                if name is None:
                    name = font[-1].split(".")[0]
                self.fonts[name] = pg.font.Font(
                    os.path.join(*font), size, bold=bold, italic=italic)
            # if image file provided as string, use it raw
            elif type(font) is str:
                if name is None:
                    name = font.rsplit(os.path)[-1].split(".")[0]
                self.fonts[name] = pg.font.Font(font, size, bold, italic)
        else:
            if name is None:
                name = font
            self.fonts[name] = pg.font.SysFont(font, size, bold, italic)

    # TODO: draw one-shot
    # TODO: replace camelcase with underscores

    # TODO: comment everything


def get_image_sequence(file):
    path = get_path(file)
    image_digits = 2  # TODO: replace get_animation
    if "{}" in path:
        image_sequence = get_animation(path, image_digits)
    else:
        image_sequence = [pg.image.load(path).convert_alpha()]

    return image_sequence

def get_animation(file, minDigits):
    '''Use {} in place of frame number'''
    # print("getting animation")
    animation = []
    filepath = get_path(file)
    animStart = False
    animEnd = False
    i = 0
    limit = 10
    count = 0
    while not animEnd:
        i += 1
        num = str(i)
        if len(num) < minDigits:
            num = "0" * (minDigits - len(num)) + num
        try:
            animation.append(pg.image.load(filepath.format(num)).convert_alpha())
            animStart = True
        except pg.error as error:
            if animStart:
                animEnd = True
            elif count > limit:
                # print("done")
                raise Exception(error)
    # print("got animation")
    return animation

def get_path(f):

    if type(f) is list:
        path = os.path.join(*f)
    elif type(f) is str:
        path = f
    else:
        raise TypeError(
            "Image is not a valid type ({}). Use a string path or a path separated into a list.".format(type(f)))
    return path

K_BACKSPACE = pg.K_BACKSPACE
K_TAB = pg.K_TAB
K_CLEAR = pg.K_CLEAR
K_RETURN = pg.K_RETURN
K_PAUSE = pg.K_PAUSE
K_ESCAPE = pg.K_ESCAPE
K_SPACE = pg.K_SPACE
K_EXCLAIM = pg.K_EXCLAIM
K_QUOTEDBL = pg.K_QUOTEDBL
K_HASH = pg.K_HASH
K_DOLLAR = pg.K_DOLLAR
K_AMPERSAND = pg.K_AMPERSAND
K_QUOTE = pg.K_QUOTE
K_LEFTPAREN = pg.K_LEFTPAREN
K_RIGHTPAREN = pg.K_RIGHTPAREN
K_ASTERISK = pg.K_ASTERISK
K_PLUS = pg.K_PLUS
K_COMMA = pg.K_COMMA
K_MINUS = pg.K_MINUS
K_PERIOD = pg.K_PERIOD
K_SLASH = pg.K_SLASH
K_0 = pg.K_0
K_1 = pg.K_1
K_2 = pg.K_2
K_3 = pg.K_3
K_4 = pg.K_4
K_5 = pg.K_5
K_6 = pg.K_6
K_7 = pg.K_7
K_8 = pg.K_8
K_9 = pg.K_9
K_COLON = pg.K_COLON
K_SEMICOLON = pg.K_SEMICOLON
K_LESS = pg.K_LESS
K_EQUALS = pg.K_EQUALS
K_GREATER = pg.K_GREATER
K_QUESTION = pg.K_QUESTION
K_AT = pg.K_AT
K_LEFTBRACKET = pg.K_LEFTBRACKET
K_BACKSLASH = pg.K_BACKSLASH
K_RIGHTBRACKET = pg.K_RIGHTBRACKET
K_CARET = pg.K_CARET
K_UNDERSCORE = pg.K_UNDERSCORE
K_BACKQUOTE = pg.K_BACKQUOTE
K_a = pg.K_a
K_b = pg.K_b
K_c = pg.K_c
K_d = pg.K_d
K_e = pg.K_e
K_f = pg.K_f
K_g = pg.K_g
K_h = pg.K_h
K_i = pg.K_i
K_j = pg.K_j
K_k = pg.K_k
K_l = pg.K_l
K_m = pg.K_m
K_n = pg.K_n
K_o = pg.K_o
K_p = pg.K_p
K_q = pg.K_q
K_r = pg.K_r
K_s = pg.K_s
K_t = pg.K_t
K_u = pg.K_u
K_v = pg.K_v
K_w = pg.K_w
K_x = pg.K_x
K_y = pg.K_y
K_z = pg.K_z
K_DELETE = pg.K_DELETE
K_KP0 = pg.K_KP0
K_KP1 = pg.K_KP1
K_KP2 = pg.K_KP2
K_KP3 = pg.K_KP3
K_KP4 = pg.K_KP4
K_KP5 = pg.K_KP5
K_KP6 = pg.K_KP6
K_KP7 = pg.K_KP7
K_KP8 = pg.K_KP8
K_KP9 = pg.K_KP9
K_KP_PERIOD = pg.K_KP_PERIOD
K_KP_DIVIDE = pg.K_KP_DIVIDE
K_KP_MULTIPLY = pg.K_KP_MULTIPLY
K_KP_MINUS = pg.K_KP_MINUS
K_KP_PLUS = pg.K_KP_PLUS
K_KP_ENTER = pg.K_KP_ENTER
K_KP_EQUALS = pg.K_KP_EQUALS
K_UP = pg.K_UP
K_DOWN = pg.K_DOWN
K_RIGHT = pg.K_RIGHT
K_LEFT = pg.K_LEFT
K_INSERT = pg.K_INSERT
K_HOME = pg.K_HOME
K_END = pg.K_END
K_PAGEUP = pg.K_PAGEUP
K_PAGEDOWN = pg.K_PAGEDOWN
K_F1 = pg.K_F1
K_F2 = pg.K_F2
K_F3 = pg.K_F3
K_F4 = pg.K_F4
K_F5 = pg.K_F5
K_F6 = pg.K_F6
K_F7 = pg.K_F7
K_F8 = pg.K_F8
K_F9 = pg.K_F9
K_F10 = pg.K_F10
K_F11 = pg.K_F11
K_F12 = pg.K_F12
K_F13 = pg.K_F13
K_F14 = pg.K_F14
K_F15 = pg.K_F15
K_NUMLOCK = pg.K_NUMLOCK
K_CAPSLOCK = pg.K_CAPSLOCK
K_SCROLLOCK = pg.K_SCROLLOCK
K_RSHIFT = pg.K_RSHIFT
K_LSHIFT = pg.K_LSHIFT
K_RCTRL = pg.K_RCTRL
K_LCTRL = pg.K_LCTRL
K_RALT = pg.K_RALT
K_LALT = pg.K_LALT
K_RMETA = pg.K_RMETA
K_LMETA = pg.K_LMETA
K_LSUPER = pg.K_LSUPER
K_RSUPER = pg.K_RSUPER
K_MODE = pg.K_MODE
K_HELP = pg.K_HELP
K_PRINT = pg.K_PRINT
K_SYSREQ = pg.K_SYSREQ
K_BREAK = pg.K_BREAK
K_MENU = pg.K_MENU
K_POWER = pg.K_POWER
K_EURO = pg.K_EURO
