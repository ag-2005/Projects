import sa_pgtraining as pgt
import random

class GameController(pgt.GameController):
    def game_start(self):
        #self.debug = True


        #highscores file
        try:
            with open("highscores.txt", "r") as highscore_file:
                self.highscore = int(highscore_file.read())
        except:
            self.highscore = 0
            with open("highscores.txt", "w") as highscore_file:
                highscore_file.write(str(self.highscore))

        
        self.back = pgt.Background(self, ["Images", "background.jpg"])
        self.score = 0
        self.score_text = pgt.Text(self, font="comic sans", text="Score:{}".format(self.score))
        self.highscore_text = pgt.Text(self, font="comic sans",
                                       text="High Score:{}".format(self.highscore),
                                       y=30)
        self.new_game()

    def new_game(self):
        self.player = Player(self, xpos=100, ypos=200)
        self.timer = 20
        self.score = 0
        
    def game_over(self):
        if self.score > self.highscore:
            self.highscore = self.score
            self.highscore_text.text = "High Score: {}".format(self.highscore)
            self.highscore_text.refresh()
            
            self.new_highscore_text = pgt.Text(self, text = "NEW HIGHSCORE!!",
                                               x=50,
                                               y=250,
                                               font="oswald",
                                               colour=pgt.YELLOW)
            
            with open("highscores.txt", "w") as highscore_file:
                highscore_file.write(str(self.highscore))
        else:
            self.new_highscore_text = pgt.Text(self, text = "", x = 50, y=250)
                
        self.paused = True
        self.game_over_text = pgt.Text(self, text="GAME OVER",
                                       x=50,
                                       y=300,
                                       font="impact",
                                       colour=pgt.RED)
        for sprite in self.all_sprites.sprites():
             sprite.kill()

    def update_event(self):
        self.back.xoffset -= self.player.hspeed / 2 
        self.timer -= 1
        if self.timer <= 0:
            Block(self, xpos=self.width + 32,
                  ypos=random.randint(150, 400) * random.choice([1, -1]),
                  collisiongroups=["blocks"])
            
            self.timer = random.randint(60, 90)
            
        self.score_text.text = "Score:{}".format(self.score)
        self.score_text.refresh()

    def pause_update(self):
        if self.get_input(pgt.K_SPACE, "press"):
            self.paused = False
            self.new_game()
            self.game_over_text.kill()
            self.new_highscore_text.kill()
#"Start" doesn't work for me. I checked the lines and they all seem fine.
            
    def font_setup(self):
        self.new_font("comic sans",
                      size=20,
                      bold=False)
        self.new_font("impact",
                      size=72)
        self.new_font("oswald",
                      size=60)
 
class Player(pgt.Sprite):
    def create_event(self):
        self.image_file = ["Images", "plane.png"]
        self.vspeed = 0
        self.hspeed = 6
        self.score_delay = 30
        self.score_timer = self.score_delay
        self.p_system = pgt.ParticleSystem(self.controller)
        self.p_emitter = pgt.ParticleEmitter(self.p_system,
                                             speed=5,
                                             speedrandom=2,
                                             direction=180,
                                             directionrandom=10,
                                             circle=10)
        self.p_smoke = pgt.Particle(image=["Images", "Smoke_0.png"],
                                           life=30,
                                           liferandom=10,
                                           gravity = 0.1,
                                           gravitydirection=-90)
                                    
                      

        
    def update_event(self):
        #movement
        if self.controller.get_input(pgt.K_SPACE, "press"):  
             self.vspeed -= 1.2
             self.p_emitter.emit(self.p_smoke, 2)
        else:
            self.vspeed += 0.9

        self.rect.y += self.vspeed

        self.image_angle = self.vspeed * -2

        self.p_emitter.x_pos = self.rect.x
        self.p_emitter.y_pos = self.rect.centery
        self.p_emitter.direction = 180-self.image_angle
        
        #game over
        if self.rect.y < 0 or self.rect.bottom > self.controller.height:
            self.controller.game_over()

        if self.get_collisions("blocks", mask = True):
            self.controller.game_over()

        #give points
        #self.score_timer -= 1
        #if self.score_timer <= 0:
        #    self.controller.score += 1
        #    print(self.controller.score)
        #    self.score_timer = self.score_delay
        

            

class Block(pgt.Sprite):
    def create_event(self):
        self.image_fill = pgt.RED
        self.image_width = 32
        self.image_height = self.controller.height
        self.score_given = False
        self.score_value = int(self.controller.player.hspeed * 2)
        
    def update_event(self):
        self.rect.x -= self.controller.player.hspeed
        self.score_value = int(self.controller.player.hspeed * 2)

        if self.rect.right < -32:
            self.kill()
            
        if self.rect.right < self.controller.player.rect.x and not self.score_given:
            self.controller.score += self.score_value
            self.score_given = True
            self.controller.player.hspeed += 0.5
        

GameController()
